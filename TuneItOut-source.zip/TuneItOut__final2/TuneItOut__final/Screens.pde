// ==================================================================
// SCREENS - the title screen and the end screen
// (drawn on top of the game, which is still visible, dimmed, behind)
// ==================================================================
class TitleScreen extends Layer {
  TitleScreen(Game game, AudioEngine audio, PixelCanvas cv) { super(game, audio, cv); }

  void drawArt() {
    pg.noStroke();
    pg.fill(10, 9, 30, 225); pg.rect(0, 0, GW, GH);
    cv.panel(30, 12, 260, 156);
  }

  void drawText() {
    tg.fill(C_TEAL); cv.setSize(16); cv.txtC("TUNE IT OUT", 160, 38);
    cv.setSize(8);
    tg.fill(C_LAV);  cv.txtC("a day with misophonia", 160, 50);

    tg.fill(C_CREAM);
    cv.txtC("Finish your essay before the deadline.", 160, 70);
    cv.txtC("Type the text shown on the screen.", 160, 82);
    cv.txtC("Headphones stay on. Sounds will come.", 160, 94);
    cv.txtC("Each time you freeze. No escape.", 160, 106);

    tg.fill(C_YEL);
    cv.txtC("CONTENT NOTE: loud sounds, flashing", 160, 126);
    cv.txtC("Start with volume LOW. TAB = mute", 160, 138);

    if ((frameCount / 30) % 2 == 0) { tg.fill(C_TEAL); cv.txtC("- PRESS ANY KEY TO START -", 160, 156); }
  }
}

class EndScreen extends Layer {
  EndScreen(Game game, AudioEngine audio, PixelCanvas cv) { super(game, audio, cv); }

  void drawArt() {
    pg.noStroke();
    pg.fill(10, 9, 30, 215); pg.rect(0, 0, GW, GH);
    cv.panel(20, 8, 280, 164);
  }

  void drawText() {
    String head, sub; int hc;
    if (game.state == S_DONE)      { head = "ESSAY SUBMITTED"; sub = "You made it. Look at what it cost.";        hc = C_TEAL; }
    else if (game.state == S_TIMEUP) { head = "TIME'S UP";       sub = "The deadline didn't care about the noise."; hc = C_RED; }
    else                           { head = "OVERWHELMED";     sub = "You had to leave the room.";                hc = C_RED; }

    tg.fill(hc); cv.setSize(16); cv.txtC(head, 160, 30);
    cv.setSize(8); tg.fill(C_LAV); cv.txtC(sub, 160, 43);

    tg.fill(C_CREAM);
    cv.txtC("Time: " + mmss(game.elapsed) + "     Triggers: " + game.triggerCount, 160, 60);
    cv.txtC("Peak overstimulation: " + int(game.peak * 100) + "%", 160, 71);
    cv.txtC("Keys pressed while frozen: " + game.lostKeys, 160, 82);
    cv.txtC("Essay written: " + int(100.0 * game.essay.typed / game.essay.length()) + "%", 160, 93);

    tg.fill(C_YEL);
    cv.txtC("Misophonia is not a game. It's daily life.", 160, 113);
    cv.txtC("It's class, work, meals and sleep. Daily.", 160, 124);
    tg.fill(C_CREAM);
    cv.txtC("Believe them. Ask what helps. Never trigger", 160, 139);
    cv.txtC("someone on purpose. It is a real condition.", 160, 150);

    if ((frameCount / 30) % 2 == 0) { tg.fill(C_TEAL); cv.txtC("- ENTER: play again -", 160, 165); }
  }
}
