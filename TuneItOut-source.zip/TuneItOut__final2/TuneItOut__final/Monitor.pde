// ==================================================================
// MONITOR - the screen with the essay on it.
//   art:  screen, blinking cursor block
//   text: the letters (they "swim" and double up as stress rises),
//         plus the flickering blind spot where you are reading
// ==================================================================
class Monitor extends Layer {
  Monitor(Game game, AudioEngine audio, PixelCanvas cv) { super(game, audio, cv); }

  // y position of a letter - words swim when stressed
  float letterY(int i) {
    float es = game.visibleStress();
    float y = TY + game.essay.line[i] * LH;
    if (es > 0.4) y += sin(frameCount * 0.25 + i * 1.7) * (es - 0.4) * 2.2;
    return round(y);
  }

  float letterX(int i) { return TX + game.essay.col[i] * CW; }

  // ---- art ---------------------------------------------------------
  void drawArt() {
    pg.noStroke();
    pg.fill(C_FRAME);    pg.rect(65, 13, 192, 108);
    pg.fill(C_DARK);     pg.rect(66, 14, 190, 106);
    pg.fill(0xFF0B1B24); pg.rect(70, 18, 182, 98);
    pg.fill(0xFF2E8F82); pg.rect(70, 18, 182, 10);
    pg.fill(0xFFE0455F); pg.rect(242, 20, 6, 6);
    pg.fill(C_YEL);      pg.rect(233, 20, 6, 6);
    pg.fill(C_CREAM);    pg.rect(76, 32, 170, 82);
    pg.fill(C_DARK);     pg.rect(155, 121, 14, 5);

    // blinking cursor block (the letter itself is drawn on the text layer)
    Essay e = game.essay;
    if (game.state == S_PLAYING && !e.isDone() && (frameCount / 25) % 2 == 0) {
      pg.fill(C_TEAL);
      pg.rect(letterX(e.typed), letterY(e.typed) - 7, CW, 9);
    }
  }

  // ---- text --------------------------------------------------------
  void drawText() {
    drawEssay();
    drawBlindSpot();
  }

  void drawEssay() {
    Essay e = game.essay;
    float es = game.stress;
    tg.fill(C_CREAM);
    cv.txtL("essay_final_FINAL.doc", 74, 26);
    for (int i = 0; i < e.length(); i++) {
      char c = e.text.charAt(i);
      if (c == ' ') continue;
      float x = letterX(i);
      float y = letterY(i);
      if (es > 0.7) { tg.fill(255, 84, 112, 110); cv.txtL(str(c), x + 1, y); }   // double vision
      tg.fill(i < e.typed ? 0xFF1E3A34 : 0xFF8F8B78);
      cv.txtL(str(c), x, y);
    }
  }

  // blind spot: a flickering patch right where you are trying to read
  void drawBlindSpot() {
    Essay e = game.essay;
    if (game.stress <= 0.65 || e.isDone()) return;
    float k = (game.stress - 0.45) / 0.55;
    float bx = letterX(e.typed) + 2, by = letterY(e.typed) - 3;
    float R = 8 + k * 18;
    for (int i = 0; i < int(60 * k); i++) {
      float ang = random(TWO_PI), d = sqrt(random(1)) * R;
      tg.fill(255, 255, 255, random(110, 230));
      tg.rect(round(bx + cos(ang) * d) * SCALE, round(by + sin(ang) * d) * SCALE, 2 * SCALE, 2 * SCALE);
    }
  }
}
