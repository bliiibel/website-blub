// ==================================================================
// POST FX - post-processing on the full-size window.
// This is where the "migraine / rage" screen effects happen:
// shake, colour split, ghosting, red vignette, tunnel vision,
// flashes and CRT scanlines. All of it scales with stress.
// ==================================================================
class PostFX {
  Game game;
  PGraphics frame;      // the finished image from the Renderer
  PImage vig;           // soft vignette mask

  PostFX(Game game, PGraphics frame) {
    this.game = game;
    this.frame = frame;
    buildVignette();
  }

  void buildVignette() {
    vig = createImage(160, 90, ARGB);
    vig.loadPixels();
    for (int y = 0; y < 90; y++) {
      for (int x = 0; x < 160; x++) {
        float dx = (x - 80) / 80.0, dy = (y - 45) / 45.0;
        float d = sqrt(dx * dx + dy * dy) / 1.414;
        float a = constrain((d - 0.35) / 0.65, 0, 1);
        a *= a;
        vig.pixels[y * 160 + x] = color(255, 255, 255, int(a * 255));
      }
    }
    vig.updatePixels();
  }

  void apply() {
    float es = game.visibleStress();
    background(0);
    noSmooth();

    drawShakyFrame(es);
    drawVignette(es);
    drawFlashes(es);
    drawScanlines();
  }

  // the game image with shake, chromatic aberration and ghosting
  void drawShakyFrame(float es) {
    float shake = es * (game.trig ? 7 : 2);
    float shx = random(-shake, shake), shy = random(-shake, shake);
    float off = es * es * 10;   // chromatic aberration

    pushMatrix();
    translate(shx, shy);
    if (off > 0.5) {
      blendMode(ADD);
      tint(255, 0, 0); image(frame, -off, 0, width, height);
      tint(0, 255, 0); image(frame, 0, 0, width, height);
      tint(0, 0, 255); image(frame, off, 0, width, height);
      blendMode(BLEND);
      noTint();
    } else {
      image(frame, 0, 0, width, height);
    }
    // ghosting / double vision
    if (es > 0.5) {
      tint(255, 70 * (es - 0.5) * 2);
      image(frame, random(-4, 4), random(-3, 3), width, height);
      noTint();
    }
    popMatrix();
  }

  // throbbing red vignette + tunnel vision
  void drawVignette(float es) {
    float a = constrain(es * 1.1 + game.pulse * 0.25 * es, 0, 1) * 255;
    if (a > 2) { tint(255, 40, 70, a); image(vig, 0, 0, width, height); }
    float tunnel = constrain((es - 0.5) * 2, 0, 1) * 200;
    if (tunnel > 2) { tint(0, 0, 0, tunnel); image(vig, 0, 0, width, height); }
    noTint();
  }

  // rage flashes (kept brief and low-contrast)
  void drawFlashes(float es) {
    noStroke();
    if (es > 0.75 && random(1) < 0.025) { fill(255, 0, 40, 70); rect(0, 0, width, height); }
    if (es > 0.6 && random(1) < 0.08)   { fill(255, 80, 100, 55); rect(0, random(height), width, random(3, 12)); }
  }

  // retro CRT scanlines
  void drawScanlines() {
    stroke(0, 45);
    strokeWeight(1);
    for (int y = 0; y < height; y += 3) line(0, y, width, y);
    noStroke();
  }
}
