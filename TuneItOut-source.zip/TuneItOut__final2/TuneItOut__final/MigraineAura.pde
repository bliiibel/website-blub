// ==================================================================
// MIGRAINE AURA - a scintillating zig-zag arc (a classic migraine
// aura) that grows as stress passes 45%
// ==================================================================
class MigraineAura extends Layer {
  MigraineAura(Game game, AudioEngine audio, PixelCanvas cv) { super(game, audio, cv); }

  void drawArt() {
    if (game.state != S_PLAYING || game.stress < 0.45) return;
    float k = (game.stress - 0.45) / 0.55;
    int[] cols = {0xFFFF5470, 0xFF4DE0C6, 0xFFFFD166, 0xFFFFFFFF, 0xFF9B83F0};

    if (frameCount % 6 < 4) {   // flickers
      float cx = 130, cy = 72, r = 14 + k * 52;
      int segs = 24;
      pg.strokeWeight(1);
      float px = 0, py = 0;
      for (int i = 0; i <= segs; i++) {
        float a = lerp(0.6 * PI, 1.8 * PI, i / (float) segs);
        float rr = r + (((i + frameCount / 3) % 2 == 0) ? 5 : -5) * k;
        float x = cx + cos(a) * rr, y = cy + sin(a) * rr * 0.9;
        if (i > 0) { pg.stroke(cols[(i + frameCount / 4) % 5]); pg.line(px, py, x, y); }
        px = x; py = y;
      }
      pg.noStroke();
    }
  }
}
