// ==================================================================
// PIXEL CANVAS - the three drawing surfaces + text helpers
//
//   pg    low-res pixel ART layer (320x180)
//   tg    full-res TEXT layer (960x540) - keeps Silkscreen crisp
//   frame art + text combined
//
// We think in the small 320x180 coordinates, but each Silkscreen
// pixel is exactly SCALE real pixels, so the letters stay crisp.
// Silkscreen is designed for sizes 8 and 16 (in small-canvas pixels).
// ==================================================================
class PixelCanvas {
  PGraphics pg, tg, frame;
  PFont font;
  boolean fontOK = true;

  PixelCanvas() {
    pg = createGraphics(GW, GH);                  pg.noSmooth();
    tg = createGraphics(GW * SCALE, GH * SCALE);  tg.noSmooth();
    frame = createGraphics(GW * SCALE, GH * SCALE); frame.noSmooth();
    font = loadSilkscreen();
  }

  // Loads Silkscreen from the data folder (also finds it in a "Silkscreen" subfolder).
  PFont loadSilkscreen() {
    String[] tries = { "Silkscreen-Regular.ttf", "Silkscreen/Silkscreen-Regular.ttf" };
    for (String t : tries) {
      if (new java.io.File(dataPath(t)).exists()) {
        fontOK = true;
        return createFont(t, 24, false);
      }
    }
    println("!! Silkscreen-Regular.ttf not found in the data folder - using a fallback font.");
    fontOK = false;
    return createFont("Monospaced.bold", 24, false);
  }

  // ---- TEXT HELPERS (all draw on "tg") -----------------------------
  void setSize(int s)              { tg.textFont(font, s * SCALE); }
  float tw(String s)               { return tg.textWidth(s) / (float) SCALE; }
  void txtL(String s, float x, float y) { tg.text(s, round(x) * SCALE, round(y) * SCALE); }
  void txtC(String s, float x, float y) { txtL(s, x - tw(s) / 2.0, y); }

  String[] wrapText(String s, float maxW) {
    String[] words = split(s, ' ');
    ArrayList<String> out = new ArrayList<String>();
    String cur = "";
    for (String w : words) {
      String test = cur.length() == 0 ? w : cur + " " + w;
      if (tw(test) > maxW && cur.length() > 0) { out.add(cur); cur = w; }
      else cur = test;
    }
    out.add(cur);
    return out.toArray(new String[0]);
  }

  // ---- ART HELPER (draws on "pg") ----------------------------------
  // a framed panel with rounded corners (used by HUD and screens)
  void panel(int x, int y, int w, int h) {
    pg.noStroke();
    pg.fill(C_FRAME);    pg.rect(x, y, w, h);
    pg.fill(0xFF0F0E24); pg.rect(x + 1, y + 1, w - 2, h - 2);
    pg.fill(0xFF2C2A58); pg.rect(x + 1, y + 1, w - 2, 1);
    pg.fill(C_BG);
    pg.rect(x, y, 1, 1); pg.rect(x + w - 1, y, 1, 1);
    pg.rect(x, y + h - 1, 1, 1); pg.rect(x + w - 1, y + h - 1, 1, 1);
  }
}
