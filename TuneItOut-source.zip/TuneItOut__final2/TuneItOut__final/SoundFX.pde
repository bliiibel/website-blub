// ==================================================================
// SOUND FX - the visual side of a trigger sound
//   art:  sound waves travelling from the source to you, and waves
//         inside the headphones (louder in there)
//   text: the big onomatopoeia word (CRUNCH, CLICK, ...)
// ==================================================================
class SoundFX extends Layer {
  SoundFX(Game game, AudioEngine audio, PixelCanvas cv) { super(game, audio, cv); }

  void drawArt() {
    if (!game.trig) return;
    float sx, sy;
    switch (game.trigType) {
      case T_CHEW:  sx = 273; sy = 88;  break;
      case T_SNIFF: sx = 273; sy = 86;  break;
      case T_PEN:   sx = 288; sy = 100; break;
      default:      sx = 301; sy = 137; break;
    }
    float intensity = game.intensity;
    pg.noFill();
    pg.strokeWeight(1);
    // waves travelling from the source toward you
    int n = 2 + int(intensity * 4);
    for (int i = 0; i < n; i++) {
      float r = (millis() * 0.04 + i * (60.0 / n)) % 60;
      float a = 200 * (1 - r / 60);
      pg.stroke(255, 209, 102, a);
      pg.arc(sx, sy, r * 2, r * 2, PI - 1.0, PI + 1.0);
    }
    // waves inside your headphones
    if (intensity > 0.3) {
      int m = 1 + int(intensity * 3);
      for (int i = 0; i < m; i++) {
        float r = (millis() * 0.05 + i * 9) % 28 + 6;
        pg.stroke(255, 84, 112, 220 * (1 - (r - 6) / 28));
        pg.ellipse(32, 76, r * 2, r * 1.6);
      }
    }
    pg.noStroke();
  }

  void drawText() {
    if (!game.trig) return;
    float intensity = game.intensity;
    int sz = intensity > 0.6 ? 16 : 8;   // Silkscreen stays crisp at 8 / 16
    cv.setSize(sz);
    float cx = (game.trigType == T_CHEW || game.trigType == T_SNIFF) ? 266 : 274;
    float wob = intensity * 1.5;
    String w = SFX_WORDS[game.trigType];
    if (intensity > 0.6) { tg.fill(255, 84, 112, 150); cv.txtC(w, cx + 3, 71 + random(-wob, wob)); }
    tg.fill(C_YEL);
    cv.txtC(w, cx + random(-wob, wob), 68 + random(-wob, wob));
    cv.setSize(8);
  }
}
