// ==================================================================
// HUD - the three panels along the bottom:
//   [overstimulation + volume]  [essay progress + interrupts]  [time + mute]
// ==================================================================
class Hud extends Layer {
  Hud(Game game, AudioEngine audio, PixelCanvas cv) { super(game, audio, cv); }

  // segmented bar. color 0 means "gradient teal -> red"
  void segBar(int x, int y, int w, int h, float v, int c) {
    int n = w / 4;
    pg.noStroke();
    for (int i = 0; i < n; i++) {
      boolean lit = i < v * n;
      int col = !lit ? 0xFF24224A : (c == 0 ? lerpColor(C_TEAL, C_RED, i / (float) n) : c);
      pg.fill(col);
      pg.rect(x + i * 4, y, 3, h);
    }
  }

  void drawArt() {
    boolean urgent = game.timeLeft < 30;
    cv.panel(6, 146, 100, 30);
    segBar(12, 159, 88, 5, game.stress, 0);
    segBar(32, 168, 68, 4, audio.volume, C_YEL);
    cv.panel(110, 146, 100, 30);
    segBar(116, 159, 88, 5, game.essay.progress(), C_TEAL);
    cv.panel(214, 146, 100, 30);
    segBar(220, 159, 88, 5, game.timeLeft / DEADLINE, urgent ? C_RED : C_YEL);
  }

  void drawText() {
    boolean urgent = game.timeLeft < 30;
    // panel 1
    tg.fill(C_LAV);   cv.txtL("OVERSTIM", 12, 156);
    tg.fill(game.stress > 0.75 ? C_RED : C_CREAM); cv.txtL(int(game.stress * 100) + "%", 78, 156);
    tg.fill(C_LAV);   cv.txtL("VOL", 12, 173);
    // panel 2
    tg.fill(C_LAV);   cv.txtL("ESSAY", 116, 156);
    tg.fill(C_CREAM); cv.txtL(int(game.essay.progress() * 100) + "%", 182, 156);
    tg.fill(C_LAV);   cv.txtL("INTERRUPTS " + game.triggerCount, 116, 173);
    // panel 3
    tg.fill(C_LAV);   cv.txtL("DUE IN", 220, 156);
    tg.fill(urgent ? C_RED : C_CREAM); cv.txtL(mmss(game.timeLeft), 282, 156);
    tg.fill(audio.muted ? C_RED : C_LAV); cv.txtL(audio.muted ? "MUTED (TAB)" : "TAB = MUTE", 220, 173);
  }
}
