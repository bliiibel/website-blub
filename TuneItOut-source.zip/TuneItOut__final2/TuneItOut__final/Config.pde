// ==================================================================
// CONFIG - everything you might want to tweak, in one place
// ==================================================================

// ------------------------------------------------------------------
// TUNING - change these to make the game easier / harder
// ------------------------------------------------------------------
final float DEADLINE      = 170;    // seconds to finish the essay
final float STRESS_GAIN   = 0.014;  // base stress per second during a trigger
final float STRESS_RAMP   = 0.045;  // extra stress per second at full intensity
final float STRESS_DECAY  = 0.06;   // recovery per second between triggers
final String ESSAY_TEXT = "social media changes how young people see themselves. "
                        + "constant comparison can lower self esteem, but online "
                        + "communities can also offer support.";

// ------------------------------------------------------------------
// LOW-RES PIXEL CANVAS (drawn small, scaled up = chunky pixels)
// ------------------------------------------------------------------
final int GW = 320, GH = 180;           // size of the pixel-art canvas
final int SCALE = 3;                    // 320x180 * 3 = 960x540 window
final int COLS = 28, CW = 6, LH = 10;   // essay layout (6px per letter = Silkscreen)
final int TX = 77, TY = 42;             // essay text origin

// ------------------------------------------------------------------
// PALETTE (Starbound-ish: deep indigo + teal + warm accents)
// ------------------------------------------------------------------
final int C_BG    = 0xFF1B1A33;
final int C_WALL  = 0xFF262449;
final int C_WALL2 = 0xFF2D2A55;
final int C_FLOOR = 0xFF14122A;
final int C_FLOOR2= 0xFF1D1A3C;
final int C_FRAME = 0xFF5C5896;
final int C_TEAL  = 0xFF4DE0C6;
final int C_RED   = 0xFFFF5470;
final int C_YEL   = 0xFFFFD166;
final int C_CREAM = 0xFFEDE6CF;
final int C_DARK  = 0xFF14122A;
final int C_LAV   = 0xFFB8B4E8;

// ------------------------------------------------------------------
// IDs
// ------------------------------------------------------------------
// game states
final int S_TITLE = 0, S_PLAYING = 1, S_DONE = 2, S_TIMEUP = 3, S_OVERWHELMED = 4;

// trigger sound types (the numbers also index SFX_WORDS)
final int T_CHEW = 0, T_PEN = 1, T_FOOT = 2, T_SNIFF = 3;

// ------------------------------------------------------------------
// TEXT
// ------------------------------------------------------------------
final String[] SFX_WORDS         = {"CRUNCH", "CLICK", "TAP TAP", "SNIFF"};
final String[] THOUGHTS_CALM     = {"ugh. chewing.", "again?", "just ignore it.", "focus. focus."};
final String[] THOUGHTS_STRAINED = {"i can't think.", "make it stop.", "why so loud?", "breathe..."};
final String[] THOUGHTS_PANIC    = {"STOP IT.", "STOP. STOP. STOP.", "i'm going to scream.", "i need to leave."};

// ------------------------------------------------------------------
// SMALL HELPERS
// ------------------------------------------------------------------
String mmss(float s) { int t = max(0, ceil(s)); return (t / 60) + ":" + nf(t % 60, 2); }
