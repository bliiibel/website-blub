// ==================================================================
// LAYER - base class for everything that gets drawn.
//
//   drawArt()   pixel art, on the low-res canvas (cv.pg)
//   drawText()  letters, on the crisp full-res canvas (cv.tg)
//               (only called while the game is being played)
//
// A subclass overrides only what it needs. Each one gets the game
// state, the audio engine and the canvas, so it can read what it
// needs to know and draw itself.
// ==================================================================
abstract class Layer {
  Game game;
  AudioEngine audio;
  PixelCanvas cv;
  PGraphics pg, tg;

  Layer(Game game, AudioEngine audio, PixelCanvas cv) {
    this.game = game;
    this.audio = audio;
    this.cv = cv;
    this.pg = cv.pg;
    this.tg = cv.tg;
  }

  void drawArt()  {}
  void drawText() {}
}
