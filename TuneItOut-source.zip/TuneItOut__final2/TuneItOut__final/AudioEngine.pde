// ==================================================================
// AUDIO ENGINE - every sound is generated in code
//   * the four trigger sounds (chew, pen click, foot tap, sniff)
//   * high-pitched ringing and a heartbeat when stressed
//   * master volume follows stress ("it's louder in the headphones")
//
// phase / clickEnv / thumpEnv are also read by Classmates, so the
// characters animate in sync with what you hear (even when muted).
// ==================================================================
class AudioEngine {
  Game game;
  WhiteNoise noise;
  BandPass bp;
  SinOsc clickOsc, thumpOsc, ringOsc, heartOsc;

  boolean muted = false;
  float volume;                 // current master volume (shown on the HUD)
  float phase, clickEnv, thumpEnv;
  int lastK = -1;
  boolean wasTrig = false;      // used to notice the moment a trigger starts

  AudioEngine(PApplet app, Game game) {
    this.game = game;
    noise = new WhiteNoise(app);
    bp = new BandPass(app);
    noise.play(); noise.amp(0);
    bp.process(noise); bp.freq(1000); bp.bw(1000);
    clickOsc = new SinOsc(app); clickOsc.play(2000, 0);
    thumpOsc = new SinOsc(app); thumpOsc.play(100, 0);
    ringOsc  = new SinOsc(app); ringOsc.play(5200, 0);
    heartOsc = new SinOsc(app); heartOsc.play(52, 0);
  }

  void toggleMute() { muted = !muted; }

  // called when a new round starts
  void reset() {
    clickEnv = 0; thumpEnv = 0; phase = 0; lastK = -1; wasTrig = false;
  }

  void update(float dt) {
    boolean playing = (game.state == S_PLAYING);
    boolean on = playing && !muted;

    // a new trigger just started: restart the sound's rhythm
    if (game.trig && !wasTrig) { phase = 0; lastK = -1; }
    wasTrig = game.trig;

    // headphones: the more stressed you are, the louder everything is
    float master = on ? constrain((0.25 + 0.75 * game.stress) * (0.45 + 0.55 * game.intensity), 0, 1) : 0;
    volume = master;

    clickEnv *= 0.7;
    thumpEnv *= 0.88;
    float nAmp = 0;

    if (game.trig && playing) nAmp = playTrigger(dt);

    noise.amp(nAmp * master);
    clickOsc.amp(clickEnv * 0.35 * master);
    thumpOsc.amp(thumpEnv * 0.6 * master);

    // high-pitched "ringing" creeps in when you are overwhelmed
    ringOsc.freq(5200 + random(-30, 30));
    ringOsc.amp(on ? pow(game.stress, 2.5) * 0.05 : 0);

    // heartbeat thump
    heartOsc.amp((on && game.stress > 0.25) ? game.pulse * 0.25 * game.stress : 0);
  }

  // advances the current trigger sound, returns the noise amplitude it wants
  float playTrigger(float dt) {
    float rate = 1 + game.intensity * 0.6;   // sounds speed up as it escalates
    float nAmp = 0;
    switch (game.trigType) {
      case T_CHEW: {   // wet noise bursts with a sharp "smack" on each bite
        phase += dt * 2.4 * rate;
        float p = phase % 1;
        nAmp = exp(-p * 7) * 0.9;
        bp.freq(p < 0.1 ? 2800 : 650);
        bp.bw(p < 0.1 ? 2000 : 700);
        break;
      }
      case T_PEN: {    // tiny sharp clicks, down-up
        phase += dt * 1.2 * rate;
        int k = floor(phase * 2);
        if (k != lastK) { lastK = k; clickEnv = 1; clickOsc.freq(k % 2 == 0 ? 2300 : 1700); }
        break;
      }
      case T_FOOT: {   // dull thumps
        phase += dt * 3.0 * rate;
        int k = floor(phase);
        if (k != lastK) { lastK = k; thumpEnv = 1; thumpOsc.freq(95 + random(15)); }
        break;
      }
      case T_SNIFF: {  // two quick breathy bursts
        phase += dt * 0.8 * rate;
        float p = phase % 1;
        float env = 0;
        if (p < 0.2) env = sin(p / 0.2 * PI);
        else if (p > 0.3 && p < 0.5) env = sin((p - 0.3) / 0.2 * PI) * 0.8;
        nAmp = env * 0.9;
        bp.freq(4200); bp.bw(3500);
        break;
      }
    }
    return nAmp;
  }
}
