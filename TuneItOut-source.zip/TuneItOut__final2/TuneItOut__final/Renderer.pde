// ==================================================================
// RENDERER - owns the canvas and every Layer.
// Draws all layers back-to-front, then combines art + text into
// "frame". (PostFX then puts that frame on the window.)
// ==================================================================
class Renderer {
  PixelCanvas cv;
  Game game;
  Layer[] layers;          // back to front
  TitleScreen title;
  EndScreen end;

  Renderer(Game game, AudioEngine audio) {
    this.game = game;
    cv = new PixelCanvas();

    layers = new Layer[] {
      new Room(game, audio, cv),
      new Classmates(game, audio, cv),
      new Player(game, audio, cv),
      new Desk(game, audio, cv),
      new Monitor(game, audio, cv),
      new Hands(game, audio, cv),
      new SoundFX(game, audio, cv),
      new MigraineAura(game, audio, cv),
      new ThoughtBubble(game, audio, cv),
      new Hud(game, audio, cv)
    };
    title = new TitleScreen(game, audio, cv);
    end   = new EndScreen(game, audio, cv);
  }

  void render() {
    // 1) pixel art
    cv.pg.beginDraw();
    for (Layer l : layers) l.drawArt();
    if (game.state == S_TITLE)      title.drawArt();
    else if (game.state >= S_DONE)  end.drawArt();
    cv.pg.endDraw();

    // 2) text, on its own full-size transparent layer
    cv.tg.beginDraw();
    cv.tg.clear();
    cv.tg.noStroke();
    cv.tg.textAlign(LEFT, BASELINE);
    cv.setSize(8);
    if (game.state == S_PLAYING) {
      for (Layer l : layers) l.drawText();
    }
    if (game.state == S_TITLE)      title.drawText();
    else if (game.state >= S_DONE)  end.drawText();
    cv.tg.endDraw();

    // 3) combine: art scaled up (no smoothing) + text on top
    cv.frame.beginDraw();
    cv.frame.background(0);
    cv.frame.image(cv.pg, 0, 0, GW * SCALE, GH * SCALE);
    cv.frame.image(cv.tg, 0, 0);
    cv.frame.endDraw();
  }
}
