// ==================================================================
// ROOM - walls, floor and the window with the tiny alien night sky
// ==================================================================
class Room extends Layer {
  int[] starX = new int[20], starY = new int[20];

  Room(Game game, AudioEngine audio, PixelCanvas cv) {
    super(game, audio, cv);
    for (int i = 0; i < starX.length; i++) { starX[i] = int(random(44)); starY[i] = int(random(42)); }
  }

  void drawArt() {
    pg.background(C_BG);
    pg.noStroke();
    pg.fill(C_WALL);  pg.rect(0, 0, GW, 140);
    pg.fill(C_WALL2); for (int x = 0; x < GW; x += 40) pg.rect(x, 0, 1, 140);
    pg.fill(C_FLOOR); pg.rect(0, 140, GW, 40);
    pg.fill(C_FLOOR2); for (int y = 148; y < GH; y += 10) pg.rect(0, y, GW, 1);

    // window
    pg.fill(C_FRAME); pg.rect(266, 8, 48, 46);
    pg.fill(0xFF0A0920); pg.rect(268, 10, 44, 42);
    for (int i = 0; i < starX.length; i++) {
      boolean twinkle = ((frameCount / 20) + i) % 5 == 0;
      pg.fill(twinkle ? 0xFFFFFFFF : 0xFF8F8BC8);
      pg.rect(268 + starX[i], 10 + starY[i], 1, 1);
    }
    pg.fill(0xFF7B5CD6); pg.ellipse(292, 36, 18, 18);
    pg.fill(0xFF9B83F0); pg.rect(287, 31, 4, 2);
    pg.fill(C_FRAME); pg.rect(289, 10, 2, 42); pg.rect(268, 30, 44, 2);
  }
}
