/*
  TUNE IT OUT - a misophonia awareness game
  -----------------------------------------
  You are a student with headphones on, trying to finish an essay.
  Trigger sounds keep coming. Every time, your character freezes,
  the sound gets louder in your headphones, and your body reacts.

  REQUIRES: the Sound library
    Sketch > Import Library > Manage Libraries... > search "Sound" > Install
  Tested on Processing 4 (Java mode).

  FONT: Silkscreen-Regular.ttf must be in the "data" folder (included).

  CONTROLS
    type the letters on the screen   = write the essay
    TAB                              = mute audio (accessibility / safety)
    ENTER                            = restart after the game ends

  ------------------------------------------------------------------
  PROJECT MAP (each tab = one file)
  ------------------------------------------------------------------
  TuneItOut__final   this tab: setup / draw / keyPressed, wires it all together
  Config             tuning numbers, layout, palette, state ids, text lists

  --- logic (no drawing) ---
  Game               state machine, stress, triggers, keyboard input
  Essay              the essay text, its on-screen layout, typing progress
  AudioEngine        all generated sound (trigger sounds, ringing, heartbeat)

  --- drawing ---
  PixelCanvas        the 3 layers (pixel art / crisp text / combined) + text helpers
  Renderer           draws every Layer in order, then combines the layers
  Layer              base class: every drawable thing has drawArt() + drawText()
    Room, Classmates, Player, Desk, Monitor, Hands,
    SoundFX, MigraineAura, ThoughtBubble, Hud, TitleScreen, EndScreen
  PostFX             full-window effects: shake, colour split, vignette, scanlines

  Every frame:  game.update -> audio.update -> renderer.render -> postFx.apply
*/

import processing.sound.*;

Game        game;
AudioEngine audio;
Renderer    renderer;
PostFX      postFx;
int lastMs;

void setup() {
  size(960, 540);
  noSmooth();
  frameRate(60);
  randomSeed(7);                       // fixed seed: same starfield (and trigger order) every run

  game     = new Game();
  audio    = new AudioEngine(this, game);   // needs "this" (the sketch) for the Sound library
  renderer = new Renderer(game, audio);
  postFx   = new PostFX(game, renderer.cv.frame);

  lastMs = millis();
}

void draw() {
  int ms = millis();
  float dt = min(0.05, (ms - lastMs) / 1000.0);
  lastMs = ms;

  game.update(dt);
  audio.update(dt);
  renderer.render();
  postFx.apply();
}

void keyPressed() {
  if (key == TAB) { audio.toggleMute(); return; }
  if (game.handleKey(key)) audio.reset();    // true = a new round just started
}
