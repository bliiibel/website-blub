// ==================================================================
// CLASSMATES - the two people making the noises.
//   classmate 1: eats a sandwich (chew) / sniffs
//   classmate 2: clicks a pen / taps a foot
// They animate in sync with the audio engine's clock.
// ==================================================================
class Classmates extends Layer {
  Classmates(Game game, AudioEngine audio, PixelCanvas cv) { super(game, audio, cv); }

  void drawArt() {
    boolean chew  = game.trig && game.trigType == T_CHEW;
    boolean sniff = game.trig && game.trigType == T_SNIFF;
    boolean pen   = game.trig && game.trigType == T_PEN;
    boolean tap   = game.trig && game.trigType == T_FOOT;
    float p = audio.phase % 1;

    pg.noStroke();
    drawEater(chew, sniff, p);
    drawClicker(pen, tap);
  }

  void drawEater(boolean chew, boolean sniff, float p) {
    int mouth = 1;
    if (chew) mouth = (p < 0.35) ? 4 : 1;
    int headDy = 0;
    if (sniff && (p < 0.2 || (p > 0.3 && p < 0.5))) headDy = -1;

    pg.fill(0xFFB5475A); pg.rect(262, 98, 22, 30);                    // body
    pg.fill(0xFFD9A066); pg.rect(265, 78 + headDy, 16, 16);           // head
    pg.fill(0xFF3A2418); pg.rect(264, 76 + headDy, 18, 5);            // hair
    pg.fill(C_DARK);     pg.rect(268, 85 + headDy, 2, 2); pg.rect(275, 85 + headDy, 2, 2);
    pg.fill(0xFF7A2030); pg.rect(270, 89 + headDy, 6, mouth);
    // arm + sandwich
    float sy = chew ? 92 - (p < 0.35 ? 2 : 0) : 98;
    pg.stroke(0xFFB5475A); pg.strokeWeight(4); pg.strokeCap(SQUARE);
    pg.line(264, 106, 258, sy + 3);
    pg.noStroke();
    pg.fill(0xFFE0B060); pg.rect(253, sy - 3, 9, 6);
    pg.fill(0xFF6FBF5A); pg.rect(254, sy, 7, 1);
  }

  void drawClicker(boolean pen, boolean tap) {
    pg.fill(0xFF4D6BD6); pg.rect(292, 100, 22, 28);                   // body
    pg.fill(0xFFC48A5A); pg.rect(295, 80, 16, 16);                    // head
    pg.fill(0xFFE8C07A); pg.rect(294, 78, 18, 5);                     // hair
    pg.fill(C_DARK);     pg.rect(298, 87, 2, 2); pg.rect(305, 87, 2, 2);
    pg.fill(0xFF7A2030); pg.rect(300, 92, 6, 1);
    // arm + pen
    pg.stroke(0xFF4D6BD6); pg.strokeWeight(4); pg.line(294, 106, 289, 104);
    pg.noStroke();
    pg.fill(C_DARK); pg.rect(287, 96, 2, 10);
    pg.fill(C_RED);  pg.rect(287, (pen && audio.clickEnv > 0.3) ? 94 : 95, 2, 2);
    // leg + shoe
    float shoe = (tap && audio.thumpEnv > 0.4) ? 135 : 138;
    pg.fill(0xFF3A2A4A); pg.rect(299, 132, 4, shoe - 130);
    pg.fill(0xFFE8E8F0); pg.rect(297, shoe, 9, 3);
  }
}
