// ==================================================================
// PLAYER - the student's body, face and headphones.
// Shakes, turns red, grits teeth and grows an anger mark
// as stress rises. (The arms live in Hands.)
// ==================================================================
class Player extends Layer {
  Player(Game game, AudioEngine audio, PixelCanvas cv) { super(game, audio, cv); }

  void drawArt() {
    boolean fz = game.frozen();
    float es = game.visibleStress();
    float tr = fz ? es * 1.5 : 0;
    int ox = int(random(-tr, tr)), oy = int(random(-tr, tr));
    int skin = lerpColor(0xFFF2C9A0, 0xFFE0455F, constrain((es - 0.4) / 0.6, 0, 1));

    pg.noStroke();
    drawBody(ox, oy, skin);
    drawFace(ox, oy, es, fz);
    drawHeadphones(ox, oy, es);
    drawStressMarks(ox, oy, es, fz);
  }

  void drawBody(int ox, int oy, int skin) {
    // hoodie
    pg.fill(0xFF3CB8A5); pg.rect(18 + ox, 94 + oy, 28, 34);
    pg.fill(0xFF2E8F82); pg.rect(18 + ox, 94 + oy, 3, 34); pg.rect(26 + ox, 94 + oy, 12, 3);
    // neck + head
    pg.fill(skin); pg.rect(27 + ox, 88 + oy, 10, 6);
    pg.rect(23 + ox, 68 + oy, 18, 20);
    // hair
    pg.fill(0xFF2A1A3A); pg.rect(22 + ox, 66 + oy, 20, 6); pg.rect(22 + ox, 72 + oy, 2, 8); pg.rect(40 + ox, 66 + oy, 3, 3);
  }

  void drawFace(int ox, int oy, float es, boolean fz) {
    pg.fill(C_DARK);
    // eyes
    if (es > 0.35 || fz) { pg.rect(27 + ox, 78 + oy, 3, 1); pg.rect(35 + ox, 78 + oy, 3, 1); }
    else                 { pg.rect(27 + ox, 77 + oy, 2, 3); pg.rect(35 + ox, 77 + oy, 2, 3); }
    // angry brows
    if (es > 0.5) {
      pg.rect(26 + ox, 75 + oy, 2, 1); pg.rect(28 + ox, 76 + oy, 2, 1);
      pg.rect(36 + ox, 76 + oy, 2, 1); pg.rect(38 + ox, 75 + oy, 2, 1);
    }
    // mouth: gritted teeth or a flat line
    if (es > 0.6 || fz) {
      pg.fill(C_CREAM); pg.rect(28 + ox, 82 + oy, 8, 3);
      pg.fill(C_DARK);  pg.rect(30 + ox, 82 + oy, 1, 3); pg.rect(33 + ox, 82 + oy, 1, 3);
    } else {
      pg.fill(C_DARK); pg.rect(29 + ox, 83 + oy, 6, 1);
    }
    // forehead vein
    if (es > 0.55) {
      pg.fill(0xFFB0102F); pg.rect(34 + ox, 70 + oy, 1, 2); pg.rect(35 + ox, 72 + oy, 2, 1);
    }
  }

  // cups glow red as the sound hurts more
  void drawHeadphones(int ox, int oy, float es) {
    int glow = lerpColor(C_TEAL, C_RED, constrain(es * 1.5, 0, 1));
    pg.fill(C_DARK);
    pg.rect(20 + ox, 62 + oy, 25, 2); pg.rect(20 + ox, 62 + oy, 2, 12); pg.rect(43 + ox, 62 + oy, 2, 12);
    pg.rect(19 + ox, 72 + oy, 5, 11); pg.rect(40 + ox, 72 + oy, 5, 11);
    pg.fill(glow);
    pg.rect(19 + ox, 74 + oy, 2, 7); pg.rect(43 + ox, 74 + oy, 2, 7);
  }

  void drawStressMarks(int ox, int oy, float es, boolean fz) {
    // headache sparks around the head
    if (es > 0.4 && (fz || es > 0.6)) {
      for (int k = 0; k < int(es * 8); k++) {
        pg.fill(random(1) < 0.5 ? C_YEL : C_RED);
        pg.rect(random(12, 54), random(56, 92), random(1, 3), random(1, 3));
      }
    }
    // anger mark
    if (es > 0.7) {
      int s = game.pulse > 0.5 ? 1 : 0;
      pg.fill(0xFFFF2D55);
      pg.rect(48 - s, 58 - s, 3, 1); pg.rect(48 - s, 58 - s, 1, 3);
      pg.rect(54 + s, 58 - s, 3, 1); pg.rect(56 + s, 58 - s, 1, 3);
      pg.rect(48 - s, 64 + s, 1, 3); pg.rect(48 - s, 66 + s, 3, 1);
      pg.rect(56 + s, 64 + s, 1, 3); pg.rect(54 + s, 66 + s, 3, 1);
    }
  }
}
