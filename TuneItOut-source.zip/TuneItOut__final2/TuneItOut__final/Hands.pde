// ==================================================================
// HANDS - typing arms normally; clamped to the ears when frozen
// (drawn after the desk and monitor so they sit in front)
// ==================================================================
class Hands extends Layer {
  Hands(Game game, AudioEngine audio, PixelCanvas cv) { super(game, audio, cv); }

  void drawArt() {
    pg.strokeCap(SQUARE);
    pg.strokeWeight(5);
    pg.stroke(0xFF3CB8A5);
    int skin = 0xFFF2C9A0;

    if (game.frozen()) {
      float tr = game.visibleStress() * 1.2;
      float lx = 20 + random(-tr, tr), rx = 44 + random(-tr, tr);
      pg.line(22, 102, lx, 84);
      pg.line(42, 102, rx, 84);
      pg.noStroke();
      pg.fill(skin);
      pg.rect(lx - 3, 80, 5, 5); pg.rect(rx - 2, 80, 5, 5);
    } else {
      int typed = game.essay.typed;
      float b = game.keyBob * 2;
      float lh = 120 - ((typed % 2 == 0) ? b : 0);
      float rh = 120 - ((typed % 2 == 1) ? b : 0);
      pg.line(24, 102, 60, lh);
      pg.line(40, 102, 80, rh);
      pg.noStroke();
      pg.fill(skin);
      pg.rect(58, lh - 2, 5, 4); pg.rect(78, rh - 2, 5, 4);
    }
    pg.noStroke();
  }
}
