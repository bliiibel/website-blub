// ==================================================================
// GAME - all the rules. No drawing and no sound in here.
//   * state machine (title / playing / finished / time up / overwhelmed)
//   * stress meter and the trigger events that feed it
//   * keyboard input
// ==================================================================
class Game {
  int state = S_TITLE;
  Essay essay = new Essay(ESSAY_TEXT);

  // how the player is doing
  float stress, baseline, peak;
  float timeLeft, elapsed;

  // the trigger sound that is happening right now (if any)
  boolean trig;
  int   trigType = -1, lastType = -1;
  float trigT, trigDur, intensity;
  float nextIn;                 // seconds until the next trigger
  float recover;                // still frozen for a moment after a trigger
  String thought = "";

  // stats for the end screen
  int triggerCount, lostKeys;

  // body animation
  float keyBob, pulse, heartPhase;

  Game() { reset(); }

  boolean frozen() { return trig || recover > 0; }

  // stress as the player *sees* it (zero on the title / end screens)
  float visibleStress() { return state == S_PLAYING ? stress : 0; }

  void reset() {
    essay.reset();
    stress = 0; baseline = 0; peak = 0;
    timeLeft = DEADLINE; elapsed = 0;
    trig = false; trigType = -1; lastType = -1; trigT = 0; intensity = 0;
    nextIn = 4; recover = 0; triggerCount = 0; lostKeys = 0; thought = "";
    keyBob = 0;
  }

  void startRound() { reset(); state = S_PLAYING; }

  // ----------------------------------------------------------------
  void update(float dt) {
    // heartbeat (speeds up with stress) - also drives visual throbbing
    heartPhase += dt * (1.0 + stress * 2.0);
    float hp = heartPhase % 1;
    pulse = exp(-hp * 12) + 0.6 * exp(-sq((hp - 0.22) * 9));
    keyBob = max(0, keyBob - dt * 8);

    if (state != S_PLAYING) return;

    elapsed += dt;
    timeLeft -= dt;
    peak = max(peak, stress);
    if (recover > 0) recover -= dt;

    if (trig) updateTrigger(dt);
    else      updateCalm(dt);

    // win / lose checks
    if (essay.isDone())        state = S_DONE;
    else if (stress >= 1.0)    state = S_OVERWHELMED;
    else if (timeLeft <= 0)    state = S_TIMEUP;
  }

  // a trigger is going on: the sound ramps up and stress climbs
  void updateTrigger(float dt) {
    trigT += dt;
    intensity = 0.25 + 0.75 * constrain(trigT / (trigDur * 0.7), 0, 1);
    stress += (STRESS_GAIN + STRESS_RAMP * intensity) * dt;
    if (trigT >= trigDur) endTrigger();
  }

  void endTrigger() {
    trig = false;
    intensity = 0;
    triggerCount++;
    baseline = min(0.4, triggerCount * 0.025);   // you never fully calm down
    recover = 0.8;                               // still frozen for a moment
    nextIn = random(2.0, 4.0) * max(0.6, 1 - triggerCount * 0.03);
  }

  // between triggers: slowly recover, count down to the next one
  void updateCalm(float dt) {
    intensity = 0;
    stress = max(baseline, stress - STRESS_DECAY * dt);
    if (recover <= 0) {
      nextIn -= dt;
      if (nextIn <= 0) startTrigger();
    }
  }

  void startTrigger() {
    int t = int(random(4));
    if (t == lastType) t = (t + 1) % 4;
    trigType = t; lastType = t;
    trig = true;
    trigT = 0;
    trigDur = random(3.5, 6.0) * (1 + stress * 0.5);
    intensity = 0.25;
    String[] pool = stress < 0.35 ? THOUGHTS_CALM : (stress < 0.7 ? THOUGHTS_STRAINED : THOUGHTS_PANIC);
    thought = pool[int(random(pool.length))];
  }

  // ----------------------------------------------------------------
  // keyboard. Returns true when a new round has just started.
  boolean handleKey(char k) {
    if (state == S_TITLE) {
      if (k != CODED) { startRound(); return true; }
      return false;
    }
    if (state >= S_DONE) {
      if (k == ENTER || k == RETURN) { startRound(); return true; }
      return false;
    }
    if (k == CODED || k < 32) return false;
    typeLetter(k);
    return false;
  }

  void typeLetter(char k) {
    if (frozen()) { lostKeys++; return; }   // you can't type while frozen

    if (Character.toLowerCase(k) == essay.nextChar()) {
      // when overstimulated, your brain sometimes drops the keystroke
      float reject = max(0, stress - 0.45) * 0.6;
      if (random(1) > reject) { essay.typed++; keyBob = 1; }
    }
  }
}
