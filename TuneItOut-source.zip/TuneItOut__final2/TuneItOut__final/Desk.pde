// ==================================================================
// DESK - the desk itself and the keyboard (a key lights up when you type)
// ==================================================================
class Desk extends Layer {
  Desk(Game game, AudioEngine audio, PixelCanvas cv) { super(game, audio, cv); }

  void drawArt() {
    pg.noStroke();
    pg.fill(0xFF6B3F2A); pg.rect(0, 126, GW, 6);
    pg.fill(0xFF8A5535); pg.rect(0, 126, GW, 2);
    pg.fill(0xFF3A2218); pg.rect(0, 132, GW, 2);
    pg.fill(0xFF4E2D1E); pg.rect(8, 134, 6, 10); pg.rect(306, 134, 6, 10);
    // keyboard
    pg.fill(0xFF3A3A5C); pg.rect(52, 121, 44, 5);
    pg.fill(0xFF8C8CB8);
    for (int k = 0; k < 10; k++) pg.rect(54 + k * 4, 122, 3, 1);
    if (game.keyBob > 0.4) { pg.fill(C_TEAL); pg.rect(54 + int(random(10)) * 4, 122, 3, 2); }
  }
}
