// ==================================================================
// THOUGHT BUBBLE - what the player is thinking while frozen.
// The text turns red and shakes when stress is high.
// ==================================================================
class ThoughtBubble extends Layer {
  ThoughtBubble(Game game, AudioEngine audio, PixelCanvas cv) { super(game, audio, cv); }

  boolean visible() { return game.frozen() && game.thought.length() > 0; }

  void drawArt() {
    if (game.state != S_PLAYING || !visible()) return;
    pg.noStroke();
    pg.fill(C_FRAME); pg.rect(2, 4, 62, 48);
    pg.fill(C_CREAM); pg.rect(3, 5, 60, 46);
    pg.rect(24, 52, 6, 2); pg.rect(25, 54, 4, 2); pg.rect(26, 56, 2, 2);   // the little tail
  }

  void drawText() {
    if (!visible()) return;
    tg.fill(game.stress > 0.7 ? 0xFFC8203F : C_DARK);
    float sh = game.stress > 0.7 ? 1.2 : 0;
    String[] lines = cv.wrapText(game.thought, 56);
    for (int i = 0; i < lines.length && i < 4; i++) {
      cv.txtL(lines[i], 7 + random(-sh, sh), 15 + i * 10 + random(-sh, sh));
    }
  }
}
