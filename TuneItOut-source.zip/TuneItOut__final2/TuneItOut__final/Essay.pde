// ==================================================================
// ESSAY - the text to type, where each letter sits on screen,
// and how far the player has typed
// ==================================================================
class Essay {
  String text;
  int typed;            // how many letters are done
  int[] line, col;      // line + column of every character

  Essay(String text) {
    this.text = text;
    layout();
  }

  void reset()          { typed = 0; }
  boolean isDone()      { return typed >= text.length(); }
  char nextChar()       { return text.charAt(typed); }
  float progress()      { return typed / (float) text.length(); }
  int length()          { return text.length(); }

  // word-wrap the text into COLS-wide lines
  void layout() {
    line = new int[text.length()];
    col  = new int[text.length()];
    int l = 0, c = 0, i = 0;
    while (i < text.length()) {
      int j = i;
      while (j < text.length() && text.charAt(j) != ' ') j++;
      int wlen = j - i;
      if (c + wlen > COLS && c > 0) { l++; c = 0; }
      for (int k = i; k < j; k++) { line[k] = l; col[k] = c++; }
      if (j < text.length()) { line[j] = l; col[j] = c++; }
      i = j + 1;
    }
  }
}
